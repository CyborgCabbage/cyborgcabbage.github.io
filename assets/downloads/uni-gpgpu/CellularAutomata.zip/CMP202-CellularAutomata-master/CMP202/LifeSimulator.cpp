#include "LifeSimulator.h"
#include <regex>
#include <cassert>

const std::array<std::string, 3> LifeSimulator::KERNEL_NAMES = {
    "Naive",
    "Tile Static",
    "Extra Threads"
};

LifeSimulator::LifeSimulator(World& world) :
    thr{&LifeSimulator::Simulate, this, std::ref(world)},
    exit{false},
    cycle{0},
    step{0},
    pause{true},
    rule{0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1},
    kernel{ Kernel::NAIVE }
{
}

LifeSimulator::LifeSimulator() :
    exit{ false },
    cycle{ 0 },
    step{ 0 },
    pause{ true },
    rule{ 0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1 },
    kernel{ Kernel::NAIVE }
{
}

LifeSimulator::~LifeSimulator() {
    Stop();
}

void LifeSimulator::Stop() {
    if(thr.joinable()){
        exit = true;
        thr.join();
    }
}

void LifeSimulator::Start(World& world) {
    assert(exit == true);
    exit = false;
    thr.swap(std::thread{ &LifeSimulator::Simulate, this, std::ref(world) });
}

int LifeSimulator::GetCycle() {
    return cycle;
}

int LifeSimulator::GetCPS() {
    return cps;
}

void LifeSimulator::SetSpeed(int val) {
    speed = val;
}

bool LifeSimulator::SetPause(bool val) {
    return pause = val;
}

void LifeSimulator::SetRule(std::array<uint32_t, 18>& rule_data) {
    rule_lock.lock();
    std::copy(rule_data.begin(), rule_data.end(), rule.begin());
    rule_lock.unlock();
}

void LifeSimulator::SetWrap(bool val) {
    wrap = val;
}

void LifeSimulator::SetKernel(Kernel val) {
    kernel = val;
}

void LifeSimulator::Step(int val) {
    step += val;
}

constexpr int TS = 8;
constexpr int TS_MASK = TS - 1;
constexpr int TSP = TS + 2;

void LifeSimulator::Simulate(World& world) {
    auto last_time = std::chrono::high_resolution_clock::now();
    int last_cycle = 0;
    while (!exit) {
        if(!pause || step > 0) {
            auto cycle_start = std::chrono::high_resolution_clock::now();
            int k = (int)kernel.load();
            StepSimulation(world, kernel);
            if (step > 0) step--;
            while(step == 0 && speed != 1000 && std::chrono::duration<double>(1.0f/(double)speed) > std::chrono::high_resolution_clock::now() - cycle_start);
        }
        auto now = std::chrono::high_resolution_clock::now();
        if (last_time + std::chrono::seconds{1} < now) {
            cps = cycle - last_cycle;
            last_cycle = cycle;
            last_time = now;
        }
    }
}

void LifeSimulator::StepSimulation(World& world, Kernel kernel) {
    auto acc_view = world.GetAcceleratorView();
    World::TextureAccessor back_ta = world.GetTexture(World::AccessType::READ, World::AccessPreference::NEWEST);
    World::TextureAccessor front_ta = world.GetTexture(World::AccessType::WRITE, World::AccessPreference::OLDEST);
    int mask = wrap ? world.GetWidth() - 1 : ~0;
    uint32_t local_rule[2][9];
    rule_lock.lock();
    std::copy(rule.begin(), rule.end(), &local_rule[0][0]);
    rule_lock.unlock();
    if (kernel == Kernel::NAIVE) {
        Concurrency::parallel_for_each(acc_view, back_ta->GetAMPTexture().extent.tile<TS, TS>(), 
            [=, &back = back_ta->GetAMPTexture(), &front = front_ta->GetAMPTexture()](tiled_index<TS, TS> t_idx) restrict(amp) {
            //Count Neighbours
            unsigned sum = 0;
            unsigned val = 0;
            sum += back(t_idx.global[0] - 1 & mask, t_idx.global[1] - 1 & mask);
            sum += back(t_idx.global[0] + 0 & mask, t_idx.global[1] - 1 & mask);
            sum += back(t_idx.global[0] + 1 & mask, t_idx.global[1] - 1 & mask);
            sum += back(t_idx.global[0] - 1 & mask, t_idx.global[1] - 0 & mask);
            val += back(t_idx.global[0] + 0 & mask, t_idx.global[1] - 0 & mask);
            sum += back(t_idx.global[0] + 1 & mask, t_idx.global[1] - 0 & mask);
            sum += back(t_idx.global[0] - 1 & mask, t_idx.global[1] + 1 & mask);
            sum += back(t_idx.global[0] + 0 & mask, t_idx.global[1] + 1 & mask);
            sum += back(t_idx.global[0] + 1 & mask, t_idx.global[1] + 1 & mask);
            unsigned result = local_rule[val][sum];
            front.set(t_idx.global, result);
        });
    }else if (kernel == Kernel::TILE_STATIC) {
        Concurrency::parallel_for_each(acc_view, back_ta->GetAMPTexture().extent.tile<TS, TS>(), 
            [=, &back = back_ta->GetAMPTexture(), &front = front_ta->GetAMPTexture()](tiled_index<TS, TS> t_idx) restrict(amp) {
            //Preload data
            tile_static unsigned t_val[TSP][TSP];
            t_val[t_idx.local[0]][t_idx.local[1]] = back(t_idx.global[0] - 1 & mask, t_idx.global[1] - 1 & mask);
            int_2 offset = int_2{ 4,4 };
            if (t_idx.local[1] >= TS - 2) {
                offset = {0,2};
            }else if(t_idx.local[0] >= TS - 2){
                offset = {2,0};
            }
            t_val[t_idx.local[0] + offset.x][t_idx.local[1] + offset.y] = back(t_idx.global[0] - 1 + offset.x & mask, t_idx.global[1] - 1 + offset.y & mask);
            t_idx.barrier.wait();
            //Count Neighbours
            unsigned sum = 0;
            unsigned val = 0;
            int x = t_idx.local[0];
            int y = t_idx.local[1];
            sum += t_val[x + 0][y + 0];
            sum += t_val[x + 1][y + 0];
            sum += t_val[x + 2][y + 0];
            sum += t_val[x + 0][y + 1];
            val += t_val[x + 1][y + 1];
            sum += t_val[x + 2][y + 1];
            sum += t_val[x + 0][y + 2];
            sum += t_val[x + 1][y + 2];
            sum += t_val[x + 2][y + 2];
            unsigned result = local_rule[val][sum];
            front.set(t_idx.global, result);
        });
    }else if(kernel == Kernel::TILE_STATIC_EXTRA_THREADS) {
        Concurrency::extent<2> extent(world.GetWidth() / TS * TSP, world.GetWidth() / TS * TSP);
        tiled_extent<TSP, TSP> t_extent(extent);
        Concurrency::parallel_for_each(acc_view, t_extent, 
            [=,&back = back_ta->GetAMPTexture(), &front = front_ta->GetAMPTexture()](tiled_index<TSP, TSP> t_idx) restrict(amp) {
            int x = t_idx.local[0];
            int y = t_idx.local[1];
            Concurrency::index<2> global{t_idx.tile * TS - 1 + t_idx.local};
            //Preload data
            tile_static unsigned t_val[TSP][TSP];
            t_val[x][y] = back(global[0] & mask, global[1] & mask);
            t_idx.barrier.wait();
            if (x >= TS || y >= TS) return;
            //Count Neighbours
            unsigned sum = 0;
            unsigned val = 0;
            sum += t_val[x + 0][y + 0];
            sum += t_val[x + 1][y + 0];
            sum += t_val[x + 2][y + 0];
            sum += t_val[x + 0][y + 1];
            val += t_val[x + 1][y + 1];
            sum += t_val[x + 2][y + 1];
            sum += t_val[x + 0][y + 2];
            sum += t_val[x + 1][y + 2];
            sum += t_val[x + 2][y + 2];
            unsigned result = local_rule[val][sum];
            front.set(global + 1, result);
        });
    }
    cycle++;
    front_ta->cycle = cycle;
}

#include "World.h"
#include <random>
#include <cassert>

const std::array<std::string, 6> World::INITIAL_PATTERN_NAMES = {
    "Full",
    "Big Island",
    "Medium Island",
    "Small Island",
    "Single Cell",
    "Border"
};

World::World(ID3D11Device* device, accelerator_view& acc_view, int width_power, float initial_fraction, InitialPattern pattern) :
acc_view{acc_view}, 
width_power{width_power},
width{ 1 << width_power }
{
    //Create initial world state
    std::default_random_engine engine(std::random_device{}());
    std::uniform_real_distribution<float> uniform_dist(0, 1);
    std::uniform_int_distribution<int> uniform_int(0, 1);
    std::vector<uint8_t> data;
    data.resize((size_t)width * width, 0);
    if (pattern == InitialPattern::FULL || pattern == InitialPattern::BIG_ISLAND || pattern == InitialPattern::MEDIUM_ISLAND || pattern == InitialPattern::SMALL_ISLAND) {
        int border_size = 0;
        switch (pattern) {
        case InitialPattern::BIG_ISLAND: border_size = width * 1 / 4; break;
        case InitialPattern::MEDIUM_ISLAND: border_size = width * 3 / 8; break;
        case InitialPattern::SMALL_ISLAND: border_size = width * 7 / 16; break;
        }
        for (int x = border_size; x < width - border_size; x++) {
            for (int y = border_size; y < width - border_size; y++) {
                if (initial_fraction == 0.5f) {
                    data[x * width + y] = uniform_int(engine);
                }
                else {
                    data[x * width + y] = uniform_dist(engine) < initial_fraction ? 1 : 0;
                }
            }
        }
    }
    else if (pattern == InitialPattern::BORDER) {
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < width; y++) {
                if (x == 0 || y == 0 || x == (width - 1) || y == (width - 1)) {
                    data[x * width + y] = uniform_dist(engine) < initial_fraction ? 1 : 0;
                }
            }
        }
    }
    else if (pattern == InitialPattern::SINGLE_CELL) {
        data[(width / 2) * width + (width / 2)] = uniform_dist(engine) < initial_fraction ? 1 : 0;
    }
    //Create world textures
    for(int i = 0; i < 3; i++) {
        textures.push_back(std::make_unique<World::Texture>(device, acc_view, width, data));
    }
}

World::TextureAccessor World::GetTexture(AccessType type, AccessPreference preference)
{
    std::lock_guard<std::recursive_mutex> _{ tam };
    int value{INT_MIN};
    Texture* ptr{nullptr};
    for(auto& tex : textures) {
        if (tex->writers > 0) continue;
        if (tex->readers > 0 && type == AccessType::WRITE) continue;
        int c = tex->cycle;
        if(preference == AccessPreference::OLDEST) c = -c;
        if(c > value) {
            value = c;
            ptr = tex.get();
        }
    }
    if(ptr == nullptr) throw std::runtime_error("Couldnt find a texture");
    return TextureAccessor{ptr, type, &tam};
}

int World::GetWidth() const
{
    return width;
}

int World::GetWidthPower() const {
    return width_power;
}

accelerator_view& World::GetAcceleratorView()
{
    return acc_view;
}

World::Texture::Texture(ID3D11Device* device, accelerator_view& acc_view, int width, std::vector<uint8_t>& data) : 
d3d_tex{CreateTexture(device,width,data)},
amp_tex{ graphics::direct3d::make_texture<uint, 2>(acc_view, d3d_tex, DXGI_FORMAT_R8_UINT) },
srv{CreateShaderView(device, d3d_tex)},
cycle{ 0 },
readers{ 0 },
writers{ 0 }
{
}

ID3D11Texture2D* World::Texture::CreateTexture(ID3D11Device* device, int width, std::vector<uint8_t>& data) {
    assert(data.size() == width * width);
    D3D11_TEXTURE2D_DESC desc{};
    desc.Width = width;
    desc.Height = width;
    desc.MipLevels = desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R8_UINT;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_UNORDERED_ACCESS;
    desc.CPUAccessFlags = 0;
    desc.MiscFlags = 0;
    D3D11_SUBRESOURCE_DATA sub{};
    sub.pSysMem = data.data();
    sub.SysMemPitch = sizeof(uint8_t) * width;
    ID3D11Texture2D* tex;
    device->CreateTexture2D(&desc, &sub, &tex);
    return tex;
}

ID3D11ShaderResourceView* World::Texture::CreateShaderView(ID3D11Device* device, ID3D11Texture2D* texture)
{
    D3D11_SHADER_RESOURCE_VIEW_DESC desc_SRV{};
    desc_SRV.Format = DXGI_FORMAT_R8_UINT;
    desc_SRV.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    desc_SRV.Texture2D.MipLevels = 1;
    ID3D11ShaderResourceView* view;
    device->CreateShaderResourceView(texture, &desc_SRV, &view);
    return view;
}

texture<uint, 2>& World::Texture::GetAMPTexture()
{
    return amp_tex;
}

ID3D11ShaderResourceView* World::Texture::GetD3DTexture()
{
    return srv;
}

World::TextureAccessor::TextureAccessor(Texture* texture, AccessType type, std::recursive_mutex* tam) : 
texture{texture}, 
type{type},
tam{tam}
{
    std::lock_guard<std::recursive_mutex> _{*tam};
    if (type == AccessType::READ) {
        texture->readers++;
    }
    else {
        texture->writers++;
    }
}

World::TextureAccessor::TextureAccessor(TextureAccessor&& other) noexcept : 
texture{other.texture},
type{other.type},
tam{other.tam}
{
    other.texture = nullptr;
}

World::TextureAccessor& World::TextureAccessor::operator=(TextureAccessor&& other) noexcept
{
    if(this != &other) {
        //Destroy existing
        if (texture != nullptr) {
            std::lock_guard<std::recursive_mutex> _{ *tam };
            if (type == AccessType::READ) {
                texture->readers--;
            }
            else {
                texture->writers--;
            }
        }
        //Move
        texture = other.texture;
        type = other.type;
        tam = other.tam;

        other.texture = nullptr;
    }
    return *this;
}

World::TextureAccessor::~TextureAccessor()
{
    if(texture != nullptr) {
        std::lock_guard<std::recursive_mutex> _{ *tam };
        if(type == AccessType::READ){
            texture->readers--;
        }else{
            texture->writers--;
        }
    }
}

World::Texture* World::TextureAccessor::operator->() const
{
    return texture;
}

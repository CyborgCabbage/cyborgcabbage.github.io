#pragma once
#include <thread>
#include <mutex>
#include "World.h"
#include <array>

class LifeSimulator
{
public:
	enum class Kernel {
		NAIVE,
		TILE_STATIC,
		TILE_STATIC_EXTRA_THREADS
	};
	static const std::array<std::string, 3> KERNEL_NAMES;
	LifeSimulator(World& world);
	LifeSimulator();
	~LifeSimulator();
	void Stop();
	void Start(World& world);
	int GetCycle();
	int GetCPS();
	void SetSpeed(int val);
	bool SetPause(bool val);
	void SetRule(std::array<uint32_t, 18>& rule_data);
	void SetWrap(bool);
	void SetKernel(Kernel);
	void Step(int val);
	void StepSimulation(World& world, Kernel kernel);
private:
	void Simulate(World& world);
	std::thread thr;
	std::mutex mut;
	std::atomic_bool exit;
	std::atomic_bool wrap;
	std::atomic_int cycle;
	std::atomic_int cps;
	std::atomic_int step;
	std::atomic_int speed;
	std::atomic_bool pause;
	std::atomic<Kernel> kernel;
	std::mutex rule_lock;
	std::array<uint32_t, 18> rule;
};


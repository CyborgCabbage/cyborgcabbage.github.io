#pragma once
#include <d3d11.h>
#define _SILENCE_AMP_DEPRECATION_WARNINGS
#include <amp_graphics.h>
#include <memory>
#include <mutex>
#include <atlbase.h>

using namespace Concurrency;
using namespace Concurrency::graphics;

class World
{
	class Texture {
	public:
		Texture(ID3D11Device* device, accelerator_view& acc_view, int width, std::vector<uint8_t>& data);
		texture<uint, 2>& GetAMPTexture();
		ID3D11ShaderResourceView* GetD3DTexture();
		int cycle;
		int readers;
		int writers;
	private:
		static ID3D11Texture2D* CreateTexture(ID3D11Device* device, int width, std::vector<uint8_t>& data);
		static ID3D11ShaderResourceView* CreateShaderView(ID3D11Device* device, ID3D11Texture2D* texture);
		CComPtr<ID3D11Texture2D> d3d_tex;
		texture<uint, 2> amp_tex;
		CComPtr<ID3D11ShaderResourceView> srv;
	};
public:
	enum class AccessType {
		READ,
		WRITE
	};
	enum class AccessPreference {
		NEWEST,
		OLDEST
	};
	class TextureAccessor {
	public:
		TextureAccessor(Texture* texture, AccessType type, std::recursive_mutex* tam);
		TextureAccessor(const TextureAccessor&) = delete;
		TextureAccessor& operator=(const TextureAccessor&) = delete;
		TextureAccessor(TextureAccessor&&) noexcept;
		TextureAccessor& operator=(TextureAccessor&& other) noexcept;
		~TextureAccessor();
		Texture* operator->() const;
	protected:
		Texture* texture;
		AccessType type;
		std::recursive_mutex* tam;
	};
	enum class InitialPattern {
		FULL,
		BIG_ISLAND,
		MEDIUM_ISLAND,
		SMALL_ISLAND,
		SINGLE_CELL,
		BORDER,
		
	};
	static const std::array<std::string, 6> INITIAL_PATTERN_NAMES;
	World(ID3D11Device* device, accelerator_view& acc_view, int width_power, float initial_fraction, InitialPattern pattern);
	TextureAccessor GetTexture(AccessType type, AccessPreference preference);
	int GetWidth() const;
	int GetWidthPower() const;
	accelerator_view& GetAcceleratorView();
private:
	accelerator_view acc_view;
	std::vector<std::unique_ptr<Texture>> textures;
	const int width;
	const int width_power;
	std::recursive_mutex tam;
};


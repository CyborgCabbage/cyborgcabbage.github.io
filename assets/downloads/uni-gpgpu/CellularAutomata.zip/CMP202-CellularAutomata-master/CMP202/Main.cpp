//AMP C++
#define _SILENCE_AMP_DEPRECATION_WARNINGS
#include <amp_graphics.h>
#include <amp_short_vectors.h>
#include <amp_math.h>
//Windows
#ifndef UNICODE
#define UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#pragma comment( lib, "user32" )
#include <atlbase.h>
#include <windowsx.h>
//Imgui
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
//DirectX
#include <d3d11.h>
#pragma comment( lib, "d3d11.lib" )
#include <dxgi.h>
#pragma comment( lib, "dxgi.lib" )
#include <d3dcompiler.h>
#pragma comment( lib, "d3dcompiler.lib" )
#include <DirectXMath.h>
#include "ThrowIfFailed.h"
//Standard Library
#include <assert.h>
#include <string>
#include <vector>
#include <random>
#include <regex>
//My Classes
#include "World.h"
#include "LifeSimulator.h"

using namespace DirectX;

ID3D11Device* device_ptr = NULL;
ID3D11DeviceContext* device_context_ptr = NULL;
IDXGISwapChain* swap_chain_ptr = NULL;
ID3D11RenderTargetView* render_target_view_ptr = NULL;

bool resize = false;

bool dragging = false;
XMFLOAT2 drag_start;
XMFLOAT2 cursor_pos;
XMFLOAT2 cam_offset;
float cam_zoom = 2;
float wheel_delta = 0;

XMFLOAT2 ScreenToWorld(HWND hwnd, XMFLOAT2 pixel) {
    RECT rect;
    GetClientRect(hwnd, &rect);
    float width = float (rect.right-rect.left);
    float height = float (rect.bottom-rect.top);
    pixel.x -= width/2;
    pixel.y -= height/2;
    XMFLOAT2 pos{cam_offset};
    pos.x += pixel.x * cam_zoom / height;
    pos.y += pixel.y * cam_zoom / height;
    return pos;
}

XMFLOAT2 ScreenToWorldLocal(HWND hwnd, XMFLOAT2 pixel) {
    RECT rect;
    GetClientRect(hwnd, &rect);
    float width = float(rect.right - rect.left);
    float height = float(rect.bottom - rect.top);
    pixel.x -= width / 2;
    pixel.y -= height / 2;
    XMFLOAT2 pos{ 0,0 };
    pos.x += pixel.x * cam_zoom / height;
    pos.y += pixel.y * cam_zoom / height;
    return pos;
}

D3D11_VIEWPORT GetViewportRect(HWND hwnd) {
    RECT winRect;
    GetClientRect(hwnd, &winRect);
    return D3D11_VIEWPORT{ 0.0f, 0.0f, (FLOAT)(winRect.right - winRect.left), (FLOAT)(winRect.bottom - winRect.top), 0.0f, 1.0f };
}

void SetViewportAndTarget(HWND hwnd) {
    CComPtr<ID3D11Texture2D> framebuffer;
    ThrowIfFailed(swap_chain_ptr->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&framebuffer));
    ThrowIfFailed(device_ptr->CreateRenderTargetView(framebuffer, 0, &render_target_view_ptr));
    /**** Rasteriser state - set viewport area *****/
    D3D11_VIEWPORT viewport = GetViewportRect(hwnd);
    device_context_ptr->RSSetViewports(1, &viewport);
    /**** Output Merger *****/
    device_context_ptr->OMSetRenderTargets(1, &render_target_view_ptr, NULL);
}

void ResizeWindow(HWND hwnd) {
    if (swap_chain_ptr)
    {
        device_context_ptr->OMSetRenderTargets(0, 0, 0);
        render_target_view_ptr->Release();
        swap_chain_ptr->ResizeBuffers(0, 0, 0, DXGI_FORMAT_UNKNOWN, 0);
        SetViewportAndTarget(hwnd);
    }
};

struct ConstantData
{
    DirectX::XMFLOAT4X4 transform;
    DirectX::XMFLOAT4 cell_colour[2];
};

CComPtr<ID3DBlob> LoadShader(const std::wstring& file, const std::string& entry_point, const std::string& target) {
    UINT flags = D3DCOMPILE_ENABLE_STRICTNESS;
#if defined( DEBUG ) || defined( _DEBUG )
    flags |= D3DCOMPILE_DEBUG; // add more debug output
#endif
    CComPtr<ID3DBlob> shader_blob;
    CComPtr<ID3DBlob> error_blob;

    // COMPILE VERTEX SHADER
    if (FAILED(D3DCompileFromFile(file.c_str(), nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE, entry_point.c_str(), target.c_str(), flags, 0, &shader_blob, &error_blob))) {
        if (error_blob) OutputDebugStringA((char*)error_blob->GetBufferPointer());
    }
    assert(shader_blob.p != nullptr);
    return shader_blob;
}

CComPtr<ID3D11VertexShader> CompileVertexShader(CComPtr<ID3DBlob>& source) {
    CComPtr<ID3D11VertexShader> vertex_shader;
    ThrowIfFailed(device_ptr->CreateVertexShader(source->GetBufferPointer(), source->GetBufferSize(), NULL, &vertex_shader));
    return vertex_shader;
}

CComPtr<ID3D11PixelShader> CompilePixelShader(CComPtr<ID3DBlob>& source) {
    CComPtr<ID3D11PixelShader> pixel_shader;
    ThrowIfFailed(device_ptr->CreatePixelShader(source->GetBufferPointer(), source->GetBufferSize(), NULL, &pixel_shader));
    return pixel_shader;
}

std::vector<std::string> rule_names;
std::vector<std::array<uint32_t, 18>> rule_data;

std::regex rule_string_regex("B[0-9]*\\/S[0-9]*");
void AddRule(const std::string& name, const std::string& rule_string) {
    std::array<uint32_t, 18> lut{};
    assert(std::regex_match(rule_string, rule_string_regex));
    int index = 0;
    for (unsigned char c : rule_string) {
        if (std::isdigit(c)) {
            int value = c - '0';
            lut[9 * index + value] = 1;
        }
        else if (c == '/') {
            index = 1;
        }
    }
    rule_names.push_back(name);
    rule_data.push_back(lut);
}

int Benchmark(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ PWSTR pCmdLine, _In_ int nCmdShow);
int Interactive(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ PWSTR pCmdLine, _In_ int nCmdShow);

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int WINAPI wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ PWSTR pCmdLine, _In_ int nCmdShow)
{
    AddRule("Static", "B/S012345678");
    AddRule("Game Of Life", "B3/S23");
    AddRule("Day And Night", "B3678/S34678");
    AddRule("Vote", "B5678/S45678");
    AddRule("Warble", "B378/S234678");
    AddRule("Mazectric", "B3/S1234");
    AddRule("Anneal", "B4678/S35678");
    AddRule("Live Free Or Die", "B2/S1");
    AddRule("Seeds", "B2/S");
    AddRule("Coral", "B3/S45678");
    AddRule("H-Tree", "B1/S012345678");
    return Interactive(hInstance, hPrevInstance, pCmdLine, nCmdShow);
    //return Benchmark(hInstance, hPrevInstance, pCmdLine, nCmdShow);
}

int Benchmark(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ PWSTR pCmdLine, _In_ int nCmdShow) {
    D3D_FEATURE_LEVEL feature_level;
    UINT flags = 0;//D3D11_CREATE_DEVICE_SINGLETHREADED;
#if defined( DEBUG ) || defined( _DEBUG )
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
    ThrowIfFailed(D3D11CreateDevice(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, flags, NULL, 0, D3D11_SDK_VERSION, &device_ptr, &feature_level, &device_context_ptr));
    auto acc_view = Concurrency::direct3d::create_accelerator_view(device_ptr);
    std::unique_ptr<LifeSimulator> simulator(new LifeSimulator());
    simulator->SetRule(rule_data[2]);
    simulator->SetWrap(true);
    auto mark = [&](const std::string& title, LifeSimulator::Kernel kernel, int world_scale, int steps){
        std::unique_ptr<World> world(new World(device_ptr, acc_view, world_scale, 0.5f, World::InitialPattern::FULL));
        auto start = std::chrono::high_resolution_clock::now();
        for(int i = 0; i < steps; i++) {
            simulator->StepSimulation(*world, kernel);
        }
        acc_view.wait();
        auto end = std::chrono::high_resolution_clock::now();
        double cells_processed = (double)(1 << world_scale) * (double)(1 << world_scale) * (double)steps;
        OutputDebugStringA((
            title+" : "+std::to_string((end - start).count()/cells_processed) + " nanoseconds per cell\n"
        ).c_str());
    };
    for(int w = 8; w <= 12; w+=2){
        const std::string res = std::to_string(1 << w);
        OutputDebugStringA((
            res + "x" + res + " cells for 4000 steps:\n"
        ).c_str());
        for (int i = 0; i < LifeSimulator::KERNEL_NAMES.size(); i++) {
            mark(LifeSimulator::KERNEL_NAMES[i], (LifeSimulator::Kernel)i, w, 4000);
        }
    }
    return 0;
}

int Interactive(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ PWSTR pCmdLine, _In_ int nCmdShow){

    // Register the window class.
    const wchar_t CLASS_NAME[] = L"Sample Window Class";

    WNDCLASS wc = { };

    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    RegisterClass(&wc);

    // Create the window.

    HWND hwnd = CreateWindowEx(
        0,                              // Optional window styles.
        CLASS_NAME,                     // Window class
        L"CMP202 - Cellular Automata",    // Window text
        WS_OVERLAPPEDWINDOW,            // Window style

        // Size and position
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,

        NULL,       // Parent window    
        NULL,       // Menu
        hInstance,  // Instance handle
        NULL        // Additional application data
    );

    if (hwnd == NULL)
    {
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);

    DXGI_SWAP_CHAIN_DESC swap_chain_descr{};
    swap_chain_descr.BufferDesc.RefreshRate.Numerator = 0;
    swap_chain_descr.BufferDesc.RefreshRate.Denominator = 1;
    swap_chain_descr.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    swap_chain_descr.SampleDesc.Count = 1;
    swap_chain_descr.SampleDesc.Quality = 0;
    swap_chain_descr.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    swap_chain_descr.BufferCount = 1;
    swap_chain_descr.OutputWindow = hwnd;
    swap_chain_descr.Windowed = true;

    D3D_FEATURE_LEVEL feature_level;
    UINT flags = 0;//D3D11_CREATE_DEVICE_SINGLETHREADED;
#if defined( DEBUG ) || defined( _DEBUG )
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
    HRESULT hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, flags, NULL, 0, D3D11_SDK_VERSION, &swap_chain_descr, &swap_chain_ptr, &device_ptr, &feature_level, &device_context_ptr);
    assert(S_OK == hr && swap_chain_ptr && device_ptr && device_context_ptr);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;

    ImGui::StyleColorsDark();

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(device_ptr, device_context_ptr);

    SetViewportAndTarget(hwnd);

    auto vs_blob = LoadShader(L"Shader.hlsl", "vs_main", "vs_5_0");
    auto vertex_shader = CompileVertexShader(vs_blob);
    std::vector<ATL::CComPtr<ID3D11PixelShader>> pixel_shaders;
    for(const std::string& entry : {"ps_main", "ps_main_average", "ps_main_high_vis"}) {
        auto ps_blob = LoadShader(L"Shader.hlsl", entry, "ps_5_0");
        pixel_shaders.push_back(CompilePixelShader(ps_blob));
    }

    CComPtr<ID3D11InputLayout> input_layout;
    D3D11_INPUT_ELEMENT_DESC input_element_desc[] = {
        { "POS", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "TEX", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        /*
        { "COL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "NOR", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        */
    };
    ThrowIfFailed(device_ptr->CreateInputLayout(input_element_desc, ARRAYSIZE(input_element_desc), vs_blob->GetBufferPointer(), vs_blob->GetBufferSize(), &input_layout));

    float vertex_data_array[] = {
        -.5f,-.5f,0,  0,0,
         .5f, .5f,0,  1,1,
        -.5f, .5f,0,  0,1,
        -.5f,-.5f,0,  0,0,
         .5f,-.5f,0,  1,0,
         .5f, .5f,0,  1,1
    };
    UINT vertex_stride = 5 * sizeof(float);
    UINT vertex_offset = 0;
    UINT vertex_count = 6;
    CComPtr<ID3D11Buffer> vertex_buffer_ptr;
    {
        D3D11_BUFFER_DESC vertex_buff_descr = {};
        vertex_buff_descr.ByteWidth = sizeof(vertex_data_array);
        vertex_buff_descr.Usage = D3D11_USAGE_DEFAULT;
        vertex_buff_descr.BindFlags = D3D11_BIND_VERTEX_BUFFER;
        D3D11_SUBRESOURCE_DATA sr_data = { 0 };
        sr_data.pSysMem = vertex_data_array;
        ThrowIfFailed(device_ptr->CreateBuffer(&vertex_buff_descr, &sr_data, &vertex_buffer_ptr));
    }
    CComPtr<ID3D11SamplerState> sampler_state;
    {
        D3D11_SAMPLER_DESC desc{};
        desc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
        desc.AddressU = D3D11_TEXTURE_ADDRESS_BORDER;
        desc.AddressV = D3D11_TEXTURE_ADDRESS_BORDER;
        desc.AddressW = D3D11_TEXTURE_ADDRESS_BORDER;
        desc.MipLODBias = 0;
        desc.MaxAnisotropy = 1;
        desc.ComparisonFunc = D3D11_COMPARISON_NEVER;
        desc.BorderColor[0] = 1;
        desc.BorderColor[1] = 1;
        desc.BorderColor[2] = 1;
        desc.BorderColor[3] = 1;
        desc.MinLOD = -FLT_MAX;
        desc.MaxLOD = FLT_MAX;
        device_ptr->CreateSamplerState(&desc, &sampler_state);
    }
    CComPtr<ID3D11Buffer> constant_buffer;
    {
        D3D11_BUFFER_DESC cbDesc{};
        cbDesc.ByteWidth = sizeof(ConstantData);
        cbDesc.Usage = D3D11_USAGE_DYNAMIC;
        cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
        cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        cbDesc.MiscFlags = 0;
        cbDesc.StructureByteStride = 0;
        ThrowIfFailed(device_ptr->CreateBuffer(&cbDesc, nullptr, &constant_buffer));
    }
    bool should_close{false};
    auto acc_view = Concurrency::direct3d::create_accelerator_view(device_ptr, Concurrency::queuing_mode_immediate);
    int world_power = 10;
    int initial_percentage = 50;
    World::InitialPattern initial_pattern{ World::InitialPattern::FULL };
    std::unique_ptr<World> world(new World(device_ptr, acc_view, world_power, initial_percentage/100.f, initial_pattern));
    std::unique_ptr<LifeSimulator> simulator(new LifeSimulator(*world.get()));
    int rule_index = 1;
    auto working_rule_data = rule_data[rule_index];
    simulator->SetRule(working_rule_data);
    bool world_wrap = true;
    simulator->SetWrap(world_wrap);
    LifeSimulator::Kernel kernel{LifeSimulator::Kernel::NAIVE};
    simulator->SetKernel(kernel);

    /***** Input Assembler (map how the vertex shader inputs should be read from vertex buffer) ******/
    device_context_ptr->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    device_context_ptr->IASetInputLayout(input_layout);
    device_context_ptr->IASetVertexBuffers(0, 1, &vertex_buffer_ptr.p, &vertex_stride, &vertex_offset);
    /*** set vertex shader to use and pixel shader to use, and constant buffers for each ***/
    device_context_ptr->VSSetShader(vertex_shader, NULL, 0);
    int current_shader = 0;
    device_context_ptr->PSSetShader(pixel_shaders[current_shader], NULL, 0);
    device_context_ptr->VSSetConstantBuffers(0, 1, &constant_buffer.p);
    device_context_ptr->PSSetConstantBuffers(0, 1, &constant_buffer.p);
    device_context_ptr->PSSetSamplers(0, 1, &sampler_state.p);
    bool pause = true;
    DirectX::XMFLOAT4 background(1.0f, 0.7f, 0.7f, 1.0f);
    DirectX::XMFLOAT4 dead_cell(0.0f, 0.0f, 0.0f, 1.0f);
    DirectX::XMFLOAT4 alive_cell(1.0f, 1.0f, 1.0f, 1.0f);
    int speed = 5;
    auto last_time = std::chrono::high_resolution_clock::now();
    int fps_count = 0;
    int fps = 0;
    
    while (!should_close) {
        /**** handle user input and other window events ****/
        MSG msg{};
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            if (msg.message == WM_QUIT) break; 
        }else{
            bool apply_button = false;
            {
                Concurrency::direct3d::d3d_access_lock(world->GetAcceleratorView());
                if(resize){
                    ResizeWindow(hwnd);
                    resize = false;
                }
            
                {//Imgui
                    ImGui_ImplDX11_NewFrame();
                    ImGui_ImplWin32_NewFrame();
                    ImGui::NewFrame();

                    const ImGuiViewport* viewport = ImGui::GetMainViewport();
                    ImGui::SetNextWindowPos({ viewport->WorkPos.x + 10.0f , viewport->WorkPos.y + 10.0f }, ImGuiCond_Always);
                    ImGui::SetNextWindowSizeConstraints(ImVec2(200.f,0.f),viewport->WorkSize);
                    ImGui::SetNextWindowBgAlpha(0.7f);
                    ImGui::Begin("Simulation Control", 0, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove);
                    if (ImGui::CollapsingHeader("World")) {
                        auto world_size = std::to_string(1 << world_power);
                        ImGui::SliderInt("##world_power", &world_power, 4, 13, (world_size+"x"+world_size).c_str());
                        ImGui::SliderInt("##initial_fraction", &initial_percentage, 0, 100, "%d%% Alive");
                        if (ImGui::BeginCombo("##patern", World::INITIAL_PATTERN_NAMES[(int)initial_pattern].c_str(), 0))
                        {
                            for (int n = 0; n < World::INITIAL_PATTERN_NAMES.size(); n++)
                            {
                                const bool is_selected = ((int)initial_pattern == n);
                                if (ImGui::Selectable(World::INITIAL_PATTERN_NAMES[n].c_str(), is_selected))
                                    initial_pattern = (World::InitialPattern)n;

                                // Set the initial focus when opening the combo (scrolling + keyboard navigation focus)
                                if (is_selected)
                                    ImGui::SetItemDefaultFocus();
                            }
                            ImGui::EndCombo();
                        }
                        apply_button = ImGui::Button("Apply##world");
                    }
                    if(ImGui::CollapsingHeader("Rule")){
                        static int item_current_idx = rule_index; // Here we store our selection data as an index.
                        if (ImGui::BeginCombo("##rule", rule_names[item_current_idx].c_str(), 0))
                        {
                            for (int n = 0; n < rule_names.size(); n++)
                            {
                                const bool is_selected = (item_current_idx == n);
                                if (ImGui::Selectable(rule_names[n].c_str(), is_selected))
                                    item_current_idx = n;

                                // Set the initial focus when opening the combo (scrolling + keyboard navigation focus)
                                if (is_selected)
                                    ImGui::SetItemDefaultFocus();
                            }
                            ImGui::EndCombo();
                        }
                        if (rule_index != item_current_idx) {
                            rule_index = item_current_idx;
                            working_rule_data = rule_data[rule_index];
                            simulator->SetRule(working_rule_data);
                        }
                        std::array<std::string, 2> row_name = {"B", "S"};
                        std::array<std::string, 2> row_tooltip_header = {
                            "Birth", 
                            "Survive" 
                        };
                        std::array<std::string, 2> row_tooltip_text = {
                            "How many neighbours does a dead cell need to become alive",
                            "How many neightbours does a living cell need to survive"
                        };
                        if (ImGui::BeginTable("table", 10, ImGuiTableFlags_Borders))
                        {
                            ImGui::TableNextColumn();
                            ImGui::Text("#");
                            for(int i = 0; i < 9; i++) {
                                ImGui::TableNextColumn();
                                ImGui::Text(std::to_string(i).c_str());
                            }
                            for (int val = 0; val < 2; val++) {
                                ImGui::TableNextColumn();
                                ImGui::Text(row_name[val].c_str());
                                if (ImGui::IsItemHovered() && ImGui::BeginTooltip())
                                {
                                    ImGui::Text(row_tooltip_header[val].c_str());
                                    ImGui::Separator();
                                    ImGui::Text(row_tooltip_text[val].c_str());
                                    ImGui::EndTooltip();
                                }
                                for (int sum = 0; sum < 9; sum++) {
                                    ImGui::TableNextColumn();
                                    uint32_t& n = working_rule_data[9 * val + sum];
                                    ImVec4 c = n ? ImVec4{ 1,1,1,1 } : ImVec4{ 0,0,0,1 };
                                    if (ImGui::ColorButton(("rb" + std::to_string(val * 9 + sum)).c_str(), c, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_NoTooltip)) {
                                        n = 1 - n;
                                        simulator->SetRule(working_rule_data);
                                    }
                                }
                            }
                            ImGui::EndTable();
                        }
                        if(working_rule_data != rule_data[rule_index]) {
                            if(ImGui::Button("Reset")) {
                                working_rule_data = rule_data[rule_index];
                                simulator->SetRule(working_rule_data);
                            }
                        }
                    }
                    if(ImGui::CollapsingHeader("Running")) {
                        ImGui::Text("Cycle %d", simulator->GetCycle());
                        if (ImGui::BeginCombo("##kernel", LifeSimulator::KERNEL_NAMES[(int)kernel].c_str(), 0))
                        {
                            for (int n = 0; n < LifeSimulator::KERNEL_NAMES.size(); n++)
                            {
                                const bool is_selected = ((int)kernel == n);
                                if (ImGui::Selectable(LifeSimulator::KERNEL_NAMES[n].c_str(), is_selected)){
                                    kernel = (LifeSimulator::Kernel)n;
                                    simulator->SetKernel(kernel);
                                }
                                // Set the initial focus when opening the combo (scrolling + keyboard navigation focus)
                                if (is_selected)
                                    ImGui::SetItemDefaultFocus();
                            }
                            ImGui::EndCombo();
                        }
                        
                        if (ImGui::Checkbox("Wrap Around", &world_wrap)) {
                            simulator->SetWrap(world_wrap);
                        }
                        
                        ImGui::SliderInt("##speed", &speed, 1, 1000, (speed == 1000) ? "Infinite" : "%d CPS", ImGuiSliderFlags_Logarithmic);
                        simulator->SetSpeed(speed);
                        ImGui::Checkbox("Pause", &pause);
                        simulator->SetPause(pause);
                        if(pause){
                            ImGui::SameLine();
                            if(ImGui::Button("Step x1")){
                                simulator->Step(1);
                            }
                            ImGui::SameLine();
                            if (ImGui::Button("x10")) {
                                simulator->Step(10);
                            }
                            ImGui::SameLine();
                            if (ImGui::Button("x100")) {
                                simulator->Step(100);
                            }
                        }
                        
                        
                        ImGui::Text("%d CPS", simulator->GetCPS());
                    }
                    //FPS
                    fps_count++;
                    auto now = std::chrono::high_resolution_clock::now();
                    if (now > last_time + std::chrono::seconds{ 1 }) {
                        last_time = now;
                        fps = fps_count;
                        fps_count = 0;
                    }
                    if(ImGui::CollapsingHeader("Render")){
                        ImGui::ColorEdit3("Background", (float*)&background, ImGuiColorEditFlags_NoInputs); // Edit 3 floats representing a color
                        ImGui::SameLine();
                        ImGui::ColorEdit3("Dead Cell", (float*)&dead_cell, ImGuiColorEditFlags_NoInputs);
                        ImGui::SameLine();
                        ImGui::ColorEdit3("Alive Cell", (float*)&alive_cell, ImGuiColorEditFlags_NoInputs);
                        const char* items[] = { "Point", "Average", "High-Vis"};
                        static int item_current_idx = current_shader; // Here we store our selection data as an index.
                        const char* combo_preview_value = items[item_current_idx];  // Pass in the preview value visible before opening the combo (it could be anything)
                        if (ImGui::BeginCombo("Shader", combo_preview_value, 0))
                        {
                            for (int n = 0; n < IM_ARRAYSIZE(items); n++)
                            {
                                const bool is_selected = (item_current_idx == n);
                                if (ImGui::Selectable(items[n], is_selected))
                                    item_current_idx = n;

                                // Set the initial focus when opening the combo (scrolling + keyboard navigation focus)
                                if (is_selected)
                                    ImGui::SetItemDefaultFocus();
                            }
                            ImGui::EndCombo();
                        }
                        if(current_shader != item_current_idx) {
                            current_shader = item_current_idx;
                            device_context_ptr->PSSetShader(pixel_shaders[current_shader], NULL, 0);
                        }
                        ImGui::Text("%d FPS", fps);
                    }
                    ImGui::End();
            
                    //Render
                    ImGui::Render();
                }
                // clear the back buffer to cornflower blue for the new frame
                device_context_ptr->ClearRenderTargetView(render_target_view_ptr, &background.x);
                //Controls
                if (wheel_delta != 0.f) {
                    float factor = std::pow(1.2f, -wheel_delta);
                    cam_zoom *= factor;
                    cam_offset.x += cursor_pos.x - cursor_pos.x * factor;
                    cam_offset.y += cursor_pos.y - cursor_pos.y * factor;
                    cursor_pos = { cursor_pos.x * factor, cursor_pos.y * factor };
                    drag_start = { drag_start.x * factor, drag_start.y * factor };

                    wheel_delta = 0;
                }
                D3D11_VIEWPORT viewport = GetViewportRect(hwnd);
                ConstantData cd{};
                float aspect = viewport.Width / viewport.Height;
                float view_width = cam_zoom*aspect;
                float view_height = cam_zoom;
                
                DirectX::XMStoreFloat4x4(&cd.transform, DirectX::XMMatrixOrthographicOffCenterLH(
                    cam_offset.x - view_width * 0.5f,
                    cam_offset.x + view_width * 0.5f,
                    cam_offset.y + view_height * 0.5f,
                    cam_offset.y - view_height * 0.5f,
                    -1.0, 1.0
                ));
                cd.cell_colour[0] = dead_cell;
                cd.cell_colour[1] = alive_cell;
                D3D11_MAPPED_SUBRESOURCE mapped;
                // Lock the constant buffer so it can be written to.
            
                device_context_ptr->Map(constant_buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
                // Copy data into buffer
                memcpy(mapped.pData, &cd, sizeof(cd));
                //Unlock buffer
                device_context_ptr->Unmap(constant_buffer, 0);

                World::TextureAccessor view = world->GetTexture(World::AccessType::READ, World::AccessPreference::NEWEST);
                auto view_ptr = view->GetD3DTexture();
                device_context_ptr->PSSetShaderResources(0, 1, &view_ptr);
            
                // draw the vertex buffer with the shaders 
                device_context_ptr->Draw(vertex_count, 0);
                //Imgui Draw
                ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
                // swap the back and front buffers (show the frame we just drew)
                swap_chain_ptr->Present(0, 0);
                ID3D11ShaderResourceView* null_view = nullptr;
                device_context_ptr->PSSetShaderResources(0, 1, &null_view);
                Concurrency::direct3d::d3d_access_unlock(world->GetAcceleratorView());
            }
            if(apply_button){
                simulator->Stop();
                world.reset(new World(device_ptr, acc_view, world_power, initial_percentage/100.f, initial_pattern));
                simulator->Start(*world.get());
            }
        }
    }
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    return 0;
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hwnd, uMsg, wParam, lParam))
        return true;
    
    switch (uMsg)
    {
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    case WM_SIZE:
        resize = true;
        return 0;
    case WM_LBUTTONDOWN:
        if(!ImGui::GetIO().WantCaptureMouse){
            dragging = true;
            drag_start = ScreenToWorldLocal(hwnd, { (float)GET_X_LPARAM(lParam), (float)GET_Y_LPARAM(lParam) });
            SetCapture(hwnd);
        }
        return 0;
    case WM_LBUTTONUP:
        dragging = false;
        ReleaseCapture();
        return 0;
    case WM_MOUSEMOVE:
        cursor_pos = ScreenToWorldLocal(hwnd, { (float)GET_X_LPARAM(lParam), (float)GET_Y_LPARAM(lParam) });
        if (dragging) {
            cam_offset.x += drag_start.x - cursor_pos.x;
            cam_offset.y += drag_start.y - cursor_pos.y;
            drag_start = cursor_pos;
        }
        return 0;
    case WM_MOUSEWHEEL:
        if(!ImGui::GetIO().WantCaptureMouse) wheel_delta += GET_WHEEL_DELTA_WPARAM(wParam) / (float)WHEEL_DELTA;
        return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}
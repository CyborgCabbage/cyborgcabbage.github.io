Texture2D<uint> diffuse : register(t0);
SamplerState my_sampler;

cbuffer ConstantData : register(b0)
{
    matrix transform;
    float4 cell_colour[2];
};

/* vertex attributes go here to input to the vertex shader */
struct vs_in
{
    float3 position_local : POS;
    float2 uv : TEX;
};

/* outputs from vertex shader go here. can be interpolated to pixel shader */
struct vs_out
{
    float4 position_clip : SV_POSITION; // required output of VS
    float2 uv : TEXCOORD;
};

vs_out vs_main(vs_in input)
{
    vs_out output = (vs_out) 0; // zero the memory first
    output.position_clip = mul(transform, float4(input.position_local, 1.0));
    output.uv = input.uv;
    return output;
}

int3 ToCoord(float2 uv)
{
    int3 coord = int3(0, 0, 0);
    diffuse.GetDimensions(coord.x, coord.y);
    coord.xy *= uv;
    return coord;
}

float4 GetColor(int3 coord)
{
    uint val = diffuse.Load(coord);
    return cell_colour[val & 1];
}

float4 GetAverageColor(int3 start, int3 end)
{
    int3 p_size = end - start + 1;
    start -= (p_size - 1) / 2;
    float4 total = float4(0, 0, 0, 0);
    int3 c = int3(0, 0, 0);
    for (c.x = 0; c.x < p_size.x; c.x++)
    {
        for (c.y = 0; c.y < p_size.y; c.y++)
        {
            total += GetColor(start + c);
        }
    }
    total /= p_size.x * p_size.y;
    return total;
}

float4 ps_main(vs_out input) : SV_TARGET
{
    return GetColor(ToCoord(input.uv));
}

float4 ps_main_average(vs_out input) : SV_TARGET
{
    float w = abs(ddx(input.uv.x));
    int3 start = ToCoord(input.uv);
    int3 end = ToCoord(input.uv + w.xx);
    return GetAverageColor(start, end);
}
float4 ps_main_high_vis(vs_out input) : SV_TARGET
{
    float w = abs(ddx(input.uv.x));
    int3 start = ToCoord(input.uv);
    int3 end = ToCoord(input.uv + w.xx);
    return pow(GetAverageColor(start, end), 0.25);
}